package demo.common;

public class AppConstants {

    public static final String CHARSET = "UTF-8";
    public static final String CUSID = "990527015206024";
    public static final String APPID = "00182350";
    public static final String APPKEY = "abc2019";
    public static final String TRXCODE_QUERYORDER = "T001";
    public static final String END_NUM = "00000001";

}
